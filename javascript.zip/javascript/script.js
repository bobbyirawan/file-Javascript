

// // deklarasi variabel
// var p, l, luas;

// // form inputan variabel
// p = prompt("masukkan panjang : ");
// l = prompt("masukkan  lebar : ");
// // operator matematika

// luas = p % l;

// // cetak
// document.write(p + "<br>");
// document.write(l + "<br>");
// document.write(luas);

// string 3 == numeric 3 //true

// string 3 === numeric 3   //false

// var nilai = prompt("silahkan masukkan nilai anda");
// 		if (nilai <= 60){
// 			alert("sayang sekali. anda tidak lulus");
// 		}else {
// 			alert("selamat anda lulus");
// 		}
// document.write("nilai anda adalah " + nilai);